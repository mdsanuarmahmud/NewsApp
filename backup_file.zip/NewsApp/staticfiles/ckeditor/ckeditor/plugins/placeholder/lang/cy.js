﻿/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("placeholder","cy",{title:"Priodweddau'r Daliwr Geiriau",toolbar:"Daliwr Geiriau",name:"Enw'r Daliwr Geiriau",invalidName:"Dyw'r daliwr geiriau methu â bod yn wag ac na all gynnyws y nodau [, ], <, > ",pathName:"daliwr geiriau"});